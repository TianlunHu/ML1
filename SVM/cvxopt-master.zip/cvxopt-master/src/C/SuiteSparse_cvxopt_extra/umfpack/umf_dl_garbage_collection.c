#define DLONG

#include "umf_garbage_collection.c"
