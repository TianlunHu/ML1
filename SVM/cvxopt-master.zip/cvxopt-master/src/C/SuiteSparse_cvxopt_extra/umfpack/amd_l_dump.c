#define DLONG

#include "amd_dump.c"
