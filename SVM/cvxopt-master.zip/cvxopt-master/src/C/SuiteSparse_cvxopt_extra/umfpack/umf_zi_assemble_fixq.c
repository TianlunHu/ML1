#define ZINT
#define FIXQ
#include "umf_assemble.c"
