#define ZLONG

#include "umf_extend_front.c"
