#define DINT
#include "umf_singletons.c"
