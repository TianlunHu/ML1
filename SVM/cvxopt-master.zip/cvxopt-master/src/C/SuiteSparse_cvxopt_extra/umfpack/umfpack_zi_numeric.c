#define ZINT
#include "umfpack_numeric.c"
