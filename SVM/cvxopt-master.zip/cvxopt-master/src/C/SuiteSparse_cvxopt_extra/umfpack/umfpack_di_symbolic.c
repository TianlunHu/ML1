#define DINT
#include "umfpack_symbolic.c"
