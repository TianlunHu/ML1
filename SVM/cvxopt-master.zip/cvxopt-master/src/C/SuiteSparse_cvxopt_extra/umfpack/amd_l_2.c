#define DLONG

#include "amd_2.c"
