#define DINT
#include "umf_valid_symbolic.c"
