#define ZINT
#include "umf_valid_symbolic.c"
