#define DLONG

#include "umf_assemble.c"
