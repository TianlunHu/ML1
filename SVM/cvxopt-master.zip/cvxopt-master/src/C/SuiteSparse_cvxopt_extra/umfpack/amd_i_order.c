#define DINT

#include "amd_order.c"
