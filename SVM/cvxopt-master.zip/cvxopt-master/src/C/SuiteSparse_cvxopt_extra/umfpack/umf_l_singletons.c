#define DLONG

#include "umf_singletons.c"
