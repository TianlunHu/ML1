#define DINT
#include "umf_scale_column.c"
