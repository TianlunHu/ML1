#define ZINT
#include "umfpack_free_numeric.c"
