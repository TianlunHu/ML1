#define ZLONG

#include "umf_local_search.c"
