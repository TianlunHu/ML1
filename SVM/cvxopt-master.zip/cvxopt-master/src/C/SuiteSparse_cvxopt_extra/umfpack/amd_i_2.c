#define DINT

#include "amd_2.c"
