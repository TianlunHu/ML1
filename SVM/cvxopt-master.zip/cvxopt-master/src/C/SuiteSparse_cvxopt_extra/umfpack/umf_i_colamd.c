#define DINT
#include "umf_colamd.c"
