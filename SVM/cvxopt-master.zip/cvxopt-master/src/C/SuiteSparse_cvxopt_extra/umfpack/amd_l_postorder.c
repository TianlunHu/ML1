#define DLONG

#include "amd_postorder.c"
